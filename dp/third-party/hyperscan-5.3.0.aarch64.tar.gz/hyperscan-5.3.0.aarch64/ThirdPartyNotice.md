# THIRD PARTY OPEN SOURCE SOFTWARE NOTICE
Please note we provide an open source software notice for the third party open source software along with this software and/or this software component contributed by Huawei (in the following just “this SOFTWARE”). The open source software licenses are granted by the respective right holders. 

# Warranty Disclaimer   
THE OPEN SOURCE SOFTWARE IN THIS SOFTWARE IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL, BUT WITHOUT ANY WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE. SEE THE APPLICABLE LICENSES FOR MORE DETAILS.

# Copyright Notice and License Texts 
Software: hyperscan 5.2.1  
Copyright notice: 

Copyright (c) 2015-2019, Intel Corporation
Copyright (c) 2015-2017, Intel Corporation
Copyright (c) 2015-2016, Intel Corporation
Copyright (c) 2015, Intel Corporation
Copyright (c) 2018, Intel Corporation
Copyright (C) 2015 Intel Corporation. All rights reserved.
Copyright
Copyright |copy| 2015-2018, Intel Corporation. All rights reserved.
Copyright (c) 2016, Intel Corporation
Copyright (c) 2015-2018, Intel Corporation
Copyright (c) 2016-2017, Intel Corporation
Copyright (c) 2017-2018, Intel Corporation
Copyright (c) 2016-2018, Intel Corporation
Copyright (c) 2017, Intel Corporation
Copyright 2008, Google Inc.
Copyright 2005, Google Inc.
Copyright 2007, Google Inc.
Copyright (c) 2018-2019, Intel Corporation
Copyright (c) 2016-2019, Intel Corporation
Copyright (C) 2005-2009 Jongsoo Park <jongsoo.park -at- gmail.com>
Copyright (c) 2004-2006, Intel Corporation
(C) As we report matches from (B) we interleave matches from the MPV if it
Copyright (c) 2017-2019, Intel Corporation
Copyright (c) 2004-2006 Intel Corporation - All Rights Reserved
Copyright (c) 2019, Intel Corporation


License: BSD 3-Clause License 

Copyright (c) <YEAR>, <OWNER>
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

